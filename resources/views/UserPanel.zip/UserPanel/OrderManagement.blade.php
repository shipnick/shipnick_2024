@extends('UserPanel.Layout')

@section('bodycontent')
<section role="main" class="content-body">

	<h2>Order Management</h2>

</section>
@endsection