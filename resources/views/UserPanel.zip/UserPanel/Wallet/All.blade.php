<!DOCTYPE html>
<html lang="en">

<head>

  <!-- All Meta -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="author" content="DexignLab">
  <meta name="robots" content="">
  <meta name="keywords" content="bootstrap admin, card, clean, credit card, dashboard template, elegant, invoice, modern, money, transaction, Transfer money, user interface, wallet">
  <meta name="description" content="Dompet is a clean-coded, responsive HTML template that can be easily customised to fit the needs of various credit card and invoice, modern, creative, Transfer money, and other businesses.">
  <meta property="og:title" content="Dompet - Payment Admin Dashboard Bootstrap Template">
  <meta property="og:description" content="Dompet is a clean-coded, responsive HTML template that can be easily customised to fit the needs of various credit card and invoice, modern, creative, Transfer money, and other businesses.">
  <meta property="og:image" content="https://dompet.dexignlab.com/xhtml/social-image.png">
  <meta name="format-detection" content="telephone=no">

  <!-- Mobile Specific -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- favicon -->
  <link rel="shortcut icon" type="image/png" href="images/favicon.png">

  <!-- Page Title Here -->
  <title>Dompet - Payment Admin Dashboard Bootstrap Template</title>



  <link href="{{asset('newtheme/vendor/datatables/css/jquery.dataTables.min.css')}}" rel="stylesheet">
  <link href="{{asset('newtheme/vendor/jquery-nice-select/css/nice-select.css')}}" rel="stylesheet">
  <link rel="stylesheet" href="{{asset('newtheme/vendor/nouislider/nouislider.min.css')}}">
  <!-- Style css -->
  <link href="{{asset('newtheme/css/style.css')}}" rel="stylesheet">

</head>

<body>

  <!--*******************
        Preloader start
    ********************-->
  <div id="preloader">
    <div class="waviy">
      <span style="--i:1">L</span>
      <span style="--i:2">o</span>
      <span style="--i:3">a</span>
      <span style="--i:4">d</span>
      <span style="--i:5">i</span>
      <span style="--i:6">n</span>
      <span style="--i:7">g</span>
      <span style="--i:8">.</span>
      <span style="--i:9">.</span>
      <span style="--i:10">.</span>
    </div>
  </div>
  <!--*******************
        Preloader end
    ********************-->

  <!--**********************************
        Main wrapper start
    ***********************************-->
  <div id="main-wrapper">

    @include("UserPanel/app")

    <!--**********************************
            Content body start
        ***********************************-->
    <div class="content-body">
      <!-- row -->
      <div class="container-fluid">
        <div class="d-flex flex-wrap align-items-center mb-3">
          <div class="mb-3 me-auto">
            <div class="card-tabs style-1 mt-3 mt-sm-0">
              <h3>Wallet Recharge History</h3>
            </div>
            <button type="button" class="btn btn-outline-primary btn-icon-text" data-bs-toggle="modal" data-bs-target="#add_tax">

                Add Balance
              </button>
          </div>

        </div>
        <div class="row">
          <div class="col-xl-12 tab-content">
            <div class="tab-pane fade show active" role="tabpanel" aria-labelledby="transaction-tab">
              <div class="table-responsive fs-14">
                <table class="table card-table display mb-4 dataTablesCard text-black" id="example5">
                  <thead>
                    <tr>
                      <th>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" value="" id="checkAll">
                          <label class="form-check-label" for="checkAll">
                          </label>
                        </div>
                      </th>
                      <th>Transaction ID</th>
                      <th>Recharge Date</th>
                      <th>Amount</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    @foreach ($params as $post)
                    <tr>
                      <td>{{ $post->id}}</td>
                      <td>{{ $post->created_at}}</td>
                      <td>{{ $post->amount }}</td>
                      <td>{{ $post->r_payment_id	 }}</td>
                      <td>{{ $post->status}}</td>
                    </tr>

                    @endforeach
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
    <!--**********************************
            Content body end
        ***********************************-->



    <!--**********************************
            Footer start
        ***********************************-->
    <div class="footer">

      <div class="copyright">
        <p>Copyright © Designed &amp; Developed by <a href="https://dexignlab.com/" target="_blank">DexignLab</a> 2023</p>
      </div>
    </div>
    <!--**********************************
            Footer end
        ***********************************-->

    <!--**********************************
           Support ticket button start
        ***********************************-->

    <!--**********************************
           Support ticket button end
        ***********************************-->


  </div>
  <!--**********************************
        Main wrapper end
    ***********************************-->
  <div id="add_tax" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Add Money</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">x</button>
        </div>
        <form class="contribution-form" id="contribution-form" method="POST" enctype="multipart/form-data" action="{{url('make-order')}}">@csrf
          <div class="text-center ">
            <div class="row my-4">
              <div class="col-md-3 my-1">
                <p> <strong>Amount</strong> </p>
              </div>
              <div class="col-md-6">
                <input type="text" placeholder="₹" class="form-control" style="border-color:#33333373;border-radius:20px" value="500" name="amount" required="">
                <!-- @error('amount') <font color="red">{{$massage}}</font> @enderror() -->
              </div>
              <div class="col-md-3"></div>

            </div>
            <!-- <div class="text-center my-3">
          <a href="#" class="btn btn-success badge">500</i></a>
          <a href="#" class="btn btn-success badge">1000</i></a>
          <a href="#" class="btn btn-success badge">2000</i></a>
          <a href="#" class="btn btn-success badge">5000</i></a>

        </div> -->
            <button class="btn btn-primary badge" type="submit"> Recharge </button>




          </div>
        </form>
        <br><br>

      </div>
    </div>
  </div>
  <!--**********************************
        Scripts
    ***********************************-->
  <!-- Required vendors -->
  <script src="{{asset('newtheme/vendor/global/global.min.js')}}"></script>
  <script src="{{asset('newtheme/vendor/chart-js/chart.bundle.min.js')}}"></script>
  <script src="{{asset('newtheme/vendor/jquery-nice-select/js/jquery.nice-select.min.js')}}"></script>

  <!-- Datatable -->
  <script src="{{asset('newtheme/vendor/datatables/js/jquery.dataTables.min.js')}}"></script>
  <script src="{{asset('newtheme/js/plugins-init/datatables.init.js')}}"></script>

  <script src="{{asset('newtheme/js/custom.min.js')}}"></script>
  <script src="{{asset('newtheme/js/dlabnav-init.js')}}"></script>

  <script>
    jQuery(document).ready(function() {
      setTimeout(function() {
        var dezSettingsOptions = {
          typography: "cairo",
          version: "light",
          layout: "vertical",
          primary: "color_10",
          headerBg: "color_1",
          navheaderBg: "color_1",
          sidebarBg: "color_10",
          sidebarStyle: "mini",
          sidebarPosition: "fixed",
          headerPosition: "fixed",
          containerLayout: "wide",
        };
        new dezSettings(dezSettingsOptions);
        jQuery(window).on('resize', function() {
          new dezSettings(dezSettingsOptions);
        })
      }, 1000)
    });
  </script>



</body>

</html>