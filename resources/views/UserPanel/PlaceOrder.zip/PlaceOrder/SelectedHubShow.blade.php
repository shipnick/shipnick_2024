<div class="row">
    <div class="col-md-1">Name</div>
    <div class="col-md-3"><input type="text" class="form-control" value="{{ ucwords($details->hub_name) }}" readonly></div>
    <div class="col-md-1">Address</div>
    <div class="col-md-7"><input type="text" class="form-control" value="{{ ucwords($details->hub_address1) }}" readonly></div>
</div>
<div class="row my-2">
    <div class="col-md-1">Mobile</div>
    <div class="col-md-3"><input type="text" class="form-control" value="{{ ucwords($details->hub_mobile) }}" readonly></div>
    <div class="col-md-1">State</div>
    <div class="col-md-3"><input type="text" class="form-control" value="{{ ucwords($details->hub_state) }}" readonly></div>
    <div class="col-md-1">City</div>
    <div class="col-md-3"><input type="text" class="form-control" value="{{ ucwords($details->hub_city) }}" readonly></div>
</div>
<div class="row my-2">
    <div class="col-md-1">Pincode</div>
    <div class="col-md-3"><input type="text" class="form-control" value="{{ ucwords($details->hub_pincode) }}" readonly></div>
</div>