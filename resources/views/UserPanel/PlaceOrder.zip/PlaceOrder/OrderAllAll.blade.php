<!DOCTYPE html>
<html lang="en">

<head>

	<!-- All Meta -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="DexignLab">
	<meta name="robots" content="">
	<meta name="keywords" content="bootstrap admin, card, clean, credit card, dashboard template, elegant, invoice, modern, money, transaction, Transfer money, user interface, wallet">
	<meta name="description" content="Dompet is a clean-coded, responsive HTML template that can be easily customised to fit the needs of various credit card and invoice, modern, creative, Transfer money, and other businesses.">
	<meta property="og:title" content="Dompet - Payment Admin Dashboard Bootstrap Template">
	<meta property="og:description" content="Dompet is a clean-coded, responsive HTML template that can be easily customised to fit the needs of various credit card and invoice, modern, creative, Transfer money, and other businesses.">
	<meta property="og:image" content="https://dompet.dexignlab.com/xhtml/social-image.png">
	<meta name="format-detection" content="telephone=no">

	<!-- Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- favicon -->
	<link rel="shortcut icon" href="{{asset('Admin/images/logo.jpg')}}" />

	<!-- Page Title Here -->
	<title>Shipnick</title>



	<link href="{{asset('newtheme/vendor/datatables/css/jquery.dataTables.min.css')}}" rel="stylesheet">
	<link href="{{asset('newtheme/vendor/jquery-nice-select/css/nice-select.css')}}" rel="stylesheet">
	<link rel="stylesheet" href="{{asset('newtheme/vendor/nouislider/nouislider.min.css')}}">
	<!-- Style css -->
	<link href="{{asset('newtheme/css/style.css')}}" rel="stylesheet">

</head>
<script src="{{url('https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js')}}"></script>


<body>

	<!--*******************
        Preloader start
    ********************-->
	<div id="preloader">
		<div class="waviy">
			<span style="--i:1">L</span>
			<span style="--i:2">o</span>
			<span style="--i:3">a</span>
			<span style="--i:4">d</span>
			<span style="--i:5">i</span>
			<span style="--i:6">n</span>
			<span style="--i:7">g</span>
			<span style="--i:8">.</span>
			<span style="--i:9">.</span>
			<span style="--i:10">.</span>
		</div>
	</div>
	<!--*******************
        Preloader end
    ********************-->

	<!--**********************************
        Main wrapper start
    ***********************************-->
	<div id="main-wrapper">

		@include("UserPanel/app")

		<!--**********************************
            Content body start
        ***********************************-->
		<div class="content-body">
			<!-- row -->
			<div class="container-fluid">
				<div class="d-flex flex-wrap align-items-center mb-3">
					<div class="mb-3 me-auto">
						<div class="card-tabs style-1 mt-3 mt-sm-0">
							<ul class="nav nav-tabs" role="tablist">
								<li class="nav-item">
									<a class="nav-link active" href="{{asset('/UPAll_All_Orders')}}">All Orders</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="{{asset('/UPAll_Orders')}}">Delivered</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="{{asset('/Transit-orders')}}">OFD</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="{{asset('/Transit-orders')}}">In Transit </a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="{{asset('/UPAll_Pending_Orders')}}">Pending</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="{{asset('/UPAll_Canceled_Orders')}}">Cancelled</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="{{asset('/UPAll_Uploaded_Orders')}}">Not Picked</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="{{asset('/UPAll_Cancel_Orders')}}">RTO</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="{{asset('/failed-orders')}}">Failed</a>
								</li>

							</ul>
						</div>
					</div>
					<a href="javascript:void(0);" class="btn btn-outline-primary mb-3"><i class="fa fa-calendar me-3 scale3"></i>Filter Date</a>
				</div>
				<div class="row">
					<div class="col-xl-12 tab-content">
						<div class="tab-pane fade show active" id="AllTransaction" role="tabpanel" aria-labelledby="transaction-tab">
							<form method="post" action="{{ asset('/filter-selected-order') }}">@csrf
								<div>
									<button name="currentbtnname" value="shippinglabel" type="submit" class="btn btn-outline-primary mb-3"><i class="fa fa-calendar me-3 scale3"></i>Print Label</button>
									<!-- <a href="javascript:void(0);" class="btn btn-outline-primary mb-3"><i class="fa fa-calendar me-3 scale3"></i>Print Label</a><br /> -->
								</div>

								<div class="table-responsive fs-14">
									<table class="table card-table display mb-4 dataTablesCard text-black" id="example5">
										<thead>
											<tr>
												<th>
													<div class="form-check">
														<input class="form-check-input" type="checkbox" value="" id="checkAll" onclick="toggle(this);">
														<label class="form-check-label" for="checkAll">
														</label>
													</div>
												</th>
												<th>AWB #</th>
												<th>ID Order(s)</th>
												<th>Date of upload</th>
												<th>Customer details</th>
												<th>Customer address</th>
												<th>Courier</th>
												<th>Status</th>
												<th class="text-end">Action</th>
											</tr>
										</thead>
										<tbody>
											@php($i = 1)
											@foreach($params as $param)
											<tr>
												<td>
													<div class="form-check">
														<input class="form-check-input" type="checkbox" name="selectedorder[]" value="<?= $param->Awb_Number ?>">
													</div>
												</td>
												<td><span>{{ $param->Awb_Number }}</span></td>
												<td><span>{{ $param->ordernoapi }}</span></td>
												<td><span class="text-nowrap">{{ $param->Rec_Time_Date }}</span></td>
												<td>
													<div class="d-flex align-items-center">
														<div>
															<h6 class="fs-16 mb-0 text-nowrap"><span>{{ $param->Name }}</span><br />
																<span>{{$param->Mobile}}</span>
															</h6>
														</div>
													</div>
												</td>
												<td><span>{{ $param->Address }}</span></td>
												<td><span>{{ $param->awb_gen_by }}</span></td>
												<td><a href="javascript:void(0)" class="btn btn-success btn-sm btn-rounded light">{{ $param->showerrors }}</a></td>
												<td class="text-end">
													<div class="dropdown dropstart">
														<a href="javascript:void(0);" class="btn-link" data-bs-toggle="dropdown" aria-expanded="false">
															<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
																<path d="M12 13C12.5523 13 13 12.5523 13 12C13 11.4477 12.5523 11 12 11C11.4477 11 11 11.4477 11 12C11 12.5523 11.4477 13 12 13Z" stroke="#575757" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
																<path d="M12 6C12.5523 6 13 5.55228 13 5C13 4.44772 12.5523 4 12 4C11.4477 4 11 4.44772 11 5C11 5.55228 11.4477 6 12 6Z" stroke="#575757" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
																<path d="M12 20C12.5523 20 13 19.5523 13 19C13 18.4477 12.5523 18 12 18C11.4477 18 11 18.4477 11 19C11 19.5523 11.4477 20 12 20Z" stroke="#575757" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
															</svg>
														</a>
														<div class="dropdown-menu">
															<a class="dropdown-item" href="javascript:void(0);"><i class="las la-times-circle text-danger scale5 me-3"></i>Cancel Order</a>
															<a class="dropdown-item" href="transaction-details.html"><i class="las la-info-circle scale5 me-3"></i>Print Label</a>
														</div>
													</div>
												</td>
											</tr>
											@php($i++)
											@endforeach
										</tbody>


									</table>
									{{$params->links('pagination::bootstrap-4')}}
								</div>
								<script>
									function toggle(source) {
										var checkboxes = document.querySelectorAll('input[type="checkbox"]');
										for (var i = 0; i < checkboxes.length; i++) {
											if (checkboxes[i] != source)
												checkboxes[i].checked = source.checked;
										}
									}
								</script>
							</form>
						</div>
						

					</div>
				</div>
			</div>
		</div>
		<!--**********************************
            Content body end
        ***********************************-->



		<!--**********************************
            Footer start
        ***********************************-->
		<div class="footer">

			<div class="copyright">
				<p>Copyright © Designed &amp; Developed by <a href="https://dexignlab.com/" target="_blank">DexignLab</a> 2023</p>
			</div>
		</div>
		<!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

		<!--**********************************
           Support ticket button end
        ***********************************-->


	</div>
	<!--**********************************
        Main wrapper end
    ***********************************-->

	<!--**********************************
        Scripts
    ***********************************-->
	<!-- Required vendors -->
	<script src="{{asset('newtheme/vendor/global/global.min.js')}}"></script>
	<script src="{{asset('newtheme/vendor/chart-js/chart.bundle.min.js')}}"></script>
	<script src="{{asset('newtheme/vendor/jquery-nice-select/js/jquery.nice-select.min.js')}}"></script>

	<!-- Datatable -->
	<script src="{{asset('newtheme/vendor/datatables/js/jquery.dataTables.min.js')}}"></script>
	<script src="{{asset('newtheme/js/plugins-init/datatables.init.js')}}"></script>

	<script src="{{asset('newtheme/js/custom.min.js')}}"></script>
	<script src="{{asset('newtheme/js/dlabnav-init.js')}}"></script>

	<script>
		jQuery(document).ready(function() {
			setTimeout(function() {
				var dezSettingsOptions = {
					typography: "cairo",
					version: "light",
					layout: "vertical",
					primary: "color_10",
					headerBg: "color_1",
					navheaderBg: "color_1",
					sidebarBg: "color_10",
					sidebarStyle: "mini",
					sidebarPosition: "fixed",
					headerPosition: "fixed",
					containerLayout: "wide",
				};
				new dezSettings(dezSettingsOptions);
				jQuery(window).on('resize', function() {
					new dezSettings(dezSettingsOptions);
				})
			}, 1000)
		});
	</script>



</body>

</html>